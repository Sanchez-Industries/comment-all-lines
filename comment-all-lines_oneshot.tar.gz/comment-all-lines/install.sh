#!/bin/bash
sudo cp comment-all-lines.py /usr/bin/comment-all-lines
sudo chmod a+x /usr/bin/comment-all-lines
echo "If no error message, then is good !"
echo "Try with 'comment-all-lines --help' first okay ? Take care it's dangerous !"

